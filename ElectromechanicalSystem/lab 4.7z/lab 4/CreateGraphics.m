% omega K1...K9

% Time = K1_1.time;
% K1 = K1_1.signals.values;
% K3 = K3_1.signals.values;
% K9 = K9_1.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K1, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K3, 'b--', 'LineWidth', 2);
% hold on;
% plot(Time, K9, 'r:', 'LineWidth', 2);
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 1","   K = 3","   K = 9");
% grid on;

% Error K1...K9

% Time = K1_E_1.time;
% K1_E = K1_E_1.signals.values;
% K3_E = K3_E_1.signals.values;
% K9_E = K9_E_1.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K1_E, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K3_E, 'b--', 'LineWidth', 2);
% hold on;
% plot(Time, K9_E, 'r:', 'LineWidth', 2);
% 
% xlabel('$t$, s');
% ylabel("\omega, rad/s");
% legend("   K = 1","   K = 3","   K = 9");
% grid on;

% y = k*u при K = 5
% % omega(t)

% Time = K_lin.time;
% K5_lin = K_lin.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K5_lin, 'g', 'LineWidth', 2);
% hold on;
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   \omega(t)");
% grid on;

% % Error(t)

% Time = K_lin_E.time;
% K5_lin_E = K_lin_E.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K5_lin_E, 'b', 'LineWidth', 2);
% hold on;
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   Error(t)");
% grid on;

% omega K1...K9

% Time = K1_W_1.time;
% K1_W = K1_W_1.signals.values;
% K3_W = K3_W_1.signals.values;
% Time1 = K5_W_1.time;
% K5_W = K5_W_1.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K1_W, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K3_W, 'b--', 'LineWidth', 2);
% hold on;
% plot(Time1, K5_W, 'r:', 'LineWidth', 2);
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 1","   K = 3","   K = 9");
% grid on;

% Error K1...K9

% Time = K1_WE_1.time;
% K1_E = K1_WE_1.signals.values;
% K3_E = K3_WE_1.signals.values;
% Time1 = K5_WE_1.time;
% K5_E = K5_WE_1.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K1_E, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K3_E, 'b--', 'LineWidth', 2);
% hold on;
% plot(Time1, K5_E, 'r:', 'LineWidth', 2);
% 
% xlabel('$t$, s');
% ylabel("\omega, rad/s");
% legend("   K = 1","   K = 3","   K = 9");
% grid on;

% KW_lin 1-6

% Time = K3_W_lin.time;
% K3_Wl = K3_W_lin.signals.values;
% K3_WlE = K3_W_lin_E.signals.values;
% K4_Wl = K4_W_lin.signals.values;
% K4_WlE = K4_W_lin_E.signals.values;
% K6_Wl = K6_W_lin.signals.values;
% K6_WlE = K6_W_lin_E.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K3_Wl, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K4_Wl, 'b:', 'LineWidth', 2);
% hold on;
% plot(Time, K6_Wl, 'b--', 'LineWidth', 2);
% 
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 3","   K = 4","   K = 6");
% grid on;

% KW_lin_E 1-6

% Time = K3_W_lin.time;
% K3_Wl = K3_W_lin.signals.values;
% K3_WlE = K3_W_lin_E.signals.values;
% K4_Wl = K4_W_lin.signals.values;
% K4_WlE = K4_W_lin_E.signals.values;
% K6_Wl = K6_W_lin.signals.values;
% K6_WlE = K6_W_lin_E.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K3_WlE, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K4_WlE, 'b:', 'LineWidth', 2);
% hold on;
% plot(Time, K6_WlE, 'b--', 'LineWidth', 2);
% 
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 3","   K = 4","   K = 6");
% grid on;

% KW_lin 1-6 для скорости роста

Time = V.time;
V_1 = V.signals.values;
V_1_E = V_e.signals.values;

set(0, 'DefaultTextInterpreter', 'latex');
set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);

plot(Time, V_1, 'g', 'LineWidth', 2);

xlabel('$t$, s');
ylabel("$\alpha$, rad");
legend("   \alpha(t)");
grid on;

% 
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 3","   K = 4","   K = 6");
% grid on;

% KW_lin_E 1-6 длс скорости роста

% Time = K3_W_lin.time;
% K3_Wl = K3_W_lin.signals.values;
% K3_WlE = K3_W_lin_E.signals.values;
% K4_Wl = K4_W_lin.signals.values;
% K4_WlE = K4_W_lin_E.signals.values;
% K6_Wl = K6_W_lin.signals.values;
% K6_WlE = K6_W_lin_E.signals.values;
% 
% set(0, 'DefaultTextInterpreter', 'latex');
% set(0,'DefaultAxesFontSize',20,'DefaultAxesFontName','Times New Roman');
% set(0,'DefaultTextFontSize',20,'DefaultTextFontName','Times New Roman');
% figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
% 
% plot(Time, K3_WlE, 'g', 'LineWidth', 2);
% hold on;
% plot(Time, K4_WlE, 'b:', 'LineWidth', 2);
% hold on;
% plot(Time, K6_WlE, 'b--', 'LineWidth', 2);
% 
% 
% xlabel('$t$, s');
% ylabel("$\omega$, rad/s");
% legend("   K = 3","   K = 4","   K = 6");
% grid on;
